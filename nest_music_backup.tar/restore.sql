--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE nest_music;
--
-- Name: nest_music; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE nest_music WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE nest_music OWNER TO postgres;

\connect nest_music

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: album; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.album (
    album_id integer NOT NULL,
    label_id integer NOT NULL,
    title character varying(256) NOT NULL,
    release_date date
);


ALTER TABLE public.album OWNER TO postgres;

--
-- Name: album_album_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.album_album_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.album_album_id_seq OWNER TO postgres;

--
-- Name: album_album_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.album_album_id_seq OWNED BY public.album.album_id;


--
-- Name: song; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.song (
    song_id integer NOT NULL,
    genre_id integer NOT NULL,
    title character varying(256) NOT NULL,
    length interval NOT NULL
);


ALTER TABLE public.song OWNER TO postgres;

--
-- Name: xref_album_song; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.xref_album_song (
    album_song_id integer NOT NULL,
    song_id integer NOT NULL,
    album_id integer NOT NULL
);


ALTER TABLE public.xref_album_song OWNER TO postgres;

--
-- Name: album_length; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.album_length AS
 SELECT xref_album_song.album_id,
    album.title AS album,
    count(song.title) AS num_songs,
    sum(song.length) AS total_length
   FROM ((public.xref_album_song
     JOIN public.album USING (album_id))
     JOIN public.song USING (song_id))
  GROUP BY album.title, xref_album_song.album_id
  ORDER BY (sum(song.length));


ALTER VIEW public.album_length OWNER TO postgres;

--
-- Name: album_review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.album_review (
    review_id integer NOT NULL,
    user_id integer NOT NULL,
    album_id integer NOT NULL,
    rating integer NOT NULL,
    "desc" character varying(512),
    review_date date DEFAULT CURRENT_DATE,
    CONSTRAINT album_review_rating_check CHECK (((rating >= 1) AND (rating <= 10)))
);


ALTER TABLE public.album_review OWNER TO postgres;

--
-- Name: album_review_count; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.album_review_count AS
 SELECT album_review.album_id,
    album.title AS album,
    count(album_review.album_id) AS reviews
   FROM (public.album_review
     JOIN public.album USING (album_id))
  GROUP BY album_review.album_id, album.title
  ORDER BY (count(album_review.album_id));


ALTER VIEW public.album_review_count OWNER TO postgres;

--
-- Name: album_review_review_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.album_review_review_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.album_review_review_id_seq OWNER TO postgres;

--
-- Name: album_review_review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.album_review_review_id_seq OWNED BY public.album_review.review_id;


--
-- Name: artist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.artist (
    artist_id integer NOT NULL,
    genre_id integer NOT NULL,
    name character varying(256) NOT NULL,
    bio_desc character varying(512)
);


ALTER TABLE public.artist OWNER TO postgres;

--
-- Name: xref_album_artist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.xref_album_artist (
    album_artist_id integer NOT NULL,
    artist_id integer NOT NULL,
    album_id integer NOT NULL
);


ALTER TABLE public.xref_album_artist OWNER TO postgres;

--
-- Name: artist_album_count; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.artist_album_count AS
 SELECT xref_album_artist.artist_id,
    artist.name AS artist,
    count(album.title) AS num_albums
   FROM ((public.xref_album_artist
     JOIN public.album USING (album_id))
     JOIN public.artist USING (artist_id))
  GROUP BY xref_album_artist.artist_id, artist.name
  ORDER BY (count(album.title));


ALTER VIEW public.artist_album_count OWNER TO postgres;

--
-- Name: artist_artist_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.artist_artist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.artist_artist_id_seq OWNER TO postgres;

--
-- Name: artist_artist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.artist_artist_id_seq OWNED BY public.artist.artist_id;


--
-- Name: artist_review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.artist_review (
    review_id integer NOT NULL,
    user_id integer NOT NULL,
    artist_id integer NOT NULL,
    rating integer NOT NULL,
    "desc" character varying(512),
    review_date date DEFAULT CURRENT_DATE,
    CONSTRAINT artist_review_rating_check CHECK (((rating >= 1) AND (rating <= 10)))
);


ALTER TABLE public.artist_review OWNER TO postgres;

--
-- Name: artist_review_count; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.artist_review_count AS
 SELECT artist_review.artist_id,
    artist.name AS artist,
    count(artist_review.artist_id) AS reviews
   FROM (public.artist_review
     JOIN public.artist USING (artist_id))
  GROUP BY artist_review.artist_id, artist.name
  ORDER BY (count(artist_review.artist_id));


ALTER VIEW public.artist_review_count OWNER TO postgres;

--
-- Name: artist_review_review_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.artist_review_review_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.artist_review_review_id_seq OWNER TO postgres;

--
-- Name: artist_review_review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.artist_review_review_id_seq OWNED BY public.artist_review.review_id;


--
-- Name: xref_artist_song; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.xref_artist_song (
    artist_song_id integer NOT NULL,
    song_id integer NOT NULL,
    artist_id integer NOT NULL
);


ALTER TABLE public.xref_artist_song OWNER TO postgres;

--
-- Name: artist_song_count; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.artist_song_count AS
 SELECT xref_artist_song.artist_id,
    artist.name AS artist,
    count(song.title) AS num_songs
   FROM ((public.xref_artist_song
     JOIN public.song USING (song_id))
     JOIN public.artist USING (artist_id))
  GROUP BY xref_artist_song.artist_id, artist.name
  ORDER BY (count(song.title));


ALTER VIEW public.artist_song_count OWNER TO postgres;

--
-- Name: genre; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.genre (
    genre_id integer NOT NULL,
    name character varying(64) NOT NULL
);


ALTER TABLE public.genre OWNER TO postgres;

--
-- Name: genre_genre_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.genre_genre_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.genre_genre_id_seq OWNER TO postgres;

--
-- Name: genre_genre_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.genre_genre_id_seq OWNED BY public.genre.genre_id;


--
-- Name: label; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.label (
    label_id integer NOT NULL,
    name character varying(256) NOT NULL,
    description character varying(512),
    founding_date date
);


ALTER TABLE public.label OWNER TO postgres;

--
-- Name: label_label_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.label_label_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.label_label_id_seq OWNER TO postgres;

--
-- Name: label_label_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.label_label_id_seq OWNED BY public.label.label_id;


--
-- Name: playlist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.playlist (
    playlist_id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(128) NOT NULL,
    description character varying(256)
);


ALTER TABLE public.playlist OWNER TO postgres;

--
-- Name: xref_playlist_song; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.xref_playlist_song (
    playlist_song_id integer NOT NULL,
    song_id integer NOT NULL,
    playlist_id integer NOT NULL
);


ALTER TABLE public.xref_playlist_song OWNER TO postgres;

--
-- Name: playlist_length; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.playlist_length AS
 SELECT xref_playlist_song.playlist_id,
    playlist.name AS playlist,
    count(song.title) AS num_songs,
    sum(song.length) AS total_length
   FROM ((public.xref_playlist_song
     JOIN public.playlist USING (playlist_id))
     JOIN public.song USING (song_id))
  GROUP BY playlist.name, xref_playlist_song.playlist_id
  ORDER BY (sum(song.length));


ALTER VIEW public.playlist_length OWNER TO postgres;

--
-- Name: playlist_playlist_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.playlist_playlist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.playlist_playlist_id_seq OWNER TO postgres;

--
-- Name: playlist_playlist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.playlist_playlist_id_seq OWNED BY public.playlist.playlist_id;


--
-- Name: song_review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.song_review (
    review_id integer NOT NULL,
    user_id integer NOT NULL,
    song_id integer NOT NULL,
    rating integer NOT NULL,
    "desc" character varying(512),
    review_date date DEFAULT CURRENT_DATE,
    CONSTRAINT song_review_rating_check CHECK (((rating >= 1) AND (rating <= 10)))
);


ALTER TABLE public.song_review OWNER TO postgres;

--
-- Name: song_review_count; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.song_review_count AS
 SELECT song_review.song_id,
    song.title AS song,
    count(song_review.song_id) AS reviews
   FROM (public.song_review
     JOIN public.song USING (song_id))
  GROUP BY song_review.song_id, song.title
  ORDER BY (count(song_review.song_id));


ALTER VIEW public.song_review_count OWNER TO postgres;

--
-- Name: song_review_review_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.song_review_review_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.song_review_review_id_seq OWNER TO postgres;

--
-- Name: song_review_review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.song_review_review_id_seq OWNED BY public.song_review.review_id;


--
-- Name: song_song_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.song_song_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.song_song_id_seq OWNER TO postgres;

--
-- Name: song_song_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.song_song_id_seq OWNED BY public.song.song_id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    user_id integer NOT NULL,
    username character varying(64) NOT NULL,
    password character varying(32) NOT NULL,
    email character varying(128) NOT NULL,
    date_of_birth date,
    join_date date NOT NULL
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: user_review_count; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.user_review_count AS
 SELECT "user".user_id,
    "user".username,
    ((count(artist_review.review_id) + count(album_review.review_id)) + count(song_review.review_id)) AS reviews
   FROM (((public."user"
     LEFT JOIN public.artist_review USING (user_id))
     LEFT JOIN public.album_review USING (user_id))
     LEFT JOIN public.song_review USING (user_id))
  GROUP BY "user".user_id, "user".username;


ALTER VIEW public.user_review_count OWNER TO postgres;

--
-- Name: user_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_user_id_seq OWNER TO postgres;

--
-- Name: user_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_user_id_seq OWNED BY public."user".user_id;


--
-- Name: xref_album_artist_album_artist_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.xref_album_artist_album_artist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.xref_album_artist_album_artist_id_seq OWNER TO postgres;

--
-- Name: xref_album_artist_album_artist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.xref_album_artist_album_artist_id_seq OWNED BY public.xref_album_artist.album_artist_id;


--
-- Name: xref_album_song_album_song_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.xref_album_song_album_song_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.xref_album_song_album_song_id_seq OWNER TO postgres;

--
-- Name: xref_album_song_album_song_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.xref_album_song_album_song_id_seq OWNED BY public.xref_album_song.album_song_id;


--
-- Name: xref_artist_song_artist_song_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.xref_artist_song_artist_song_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.xref_artist_song_artist_song_id_seq OWNER TO postgres;

--
-- Name: xref_artist_song_artist_song_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.xref_artist_song_artist_song_id_seq OWNED BY public.xref_artist_song.artist_song_id;


--
-- Name: xref_playlist_song_playlist_song_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.xref_playlist_song_playlist_song_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.xref_playlist_song_playlist_song_id_seq OWNER TO postgres;

--
-- Name: xref_playlist_song_playlist_song_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.xref_playlist_song_playlist_song_id_seq OWNED BY public.xref_playlist_song.playlist_song_id;


--
-- Name: album album_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.album ALTER COLUMN album_id SET DEFAULT nextval('public.album_album_id_seq'::regclass);


--
-- Name: album_review review_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.album_review ALTER COLUMN review_id SET DEFAULT nextval('public.album_review_review_id_seq'::regclass);


--
-- Name: artist artist_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.artist ALTER COLUMN artist_id SET DEFAULT nextval('public.artist_artist_id_seq'::regclass);


--
-- Name: artist_review review_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.artist_review ALTER COLUMN review_id SET DEFAULT nextval('public.artist_review_review_id_seq'::regclass);


--
-- Name: genre genre_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genre ALTER COLUMN genre_id SET DEFAULT nextval('public.genre_genre_id_seq'::regclass);


--
-- Name: label label_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.label ALTER COLUMN label_id SET DEFAULT nextval('public.label_label_id_seq'::regclass);


--
-- Name: playlist playlist_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist ALTER COLUMN playlist_id SET DEFAULT nextval('public.playlist_playlist_id_seq'::regclass);


--
-- Name: song song_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song ALTER COLUMN song_id SET DEFAULT nextval('public.song_song_id_seq'::regclass);


--
-- Name: song_review review_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song_review ALTER COLUMN review_id SET DEFAULT nextval('public.song_review_review_id_seq'::regclass);


--
-- Name: user user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user" ALTER COLUMN user_id SET DEFAULT nextval('public.user_user_id_seq'::regclass);


--
-- Name: xref_album_artist album_artist_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xref_album_artist ALTER COLUMN album_artist_id SET DEFAULT nextval('public.xref_album_artist_album_artist_id_seq'::regclass);


--
-- Name: xref_album_song album_song_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xref_album_song ALTER COLUMN album_song_id SET DEFAULT nextval('public.xref_album_song_album_song_id_seq'::regclass);


--
-- Name: xref_artist_song artist_song_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xref_artist_song ALTER COLUMN artist_song_id SET DEFAULT nextval('public.xref_artist_song_artist_song_id_seq'::regclass);


--
-- Name: xref_playlist_song playlist_song_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xref_playlist_song ALTER COLUMN playlist_song_id SET DEFAULT nextval('public.xref_playlist_song_playlist_song_id_seq'::regclass);


--
-- Data for Name: album; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.album (album_id, label_id, title, release_date) FROM stdin;
\.
COPY public.album (album_id, label_id, title, release_date) FROM '$$PATH$$/3770.dat';

--
-- Data for Name: album_review; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.album_review (review_id, user_id, album_id, rating, "desc", review_date) FROM stdin;
\.
COPY public.album_review (review_id, user_id, album_id, rating, "desc", review_date) FROM '$$PATH$$/3780.dat';

--
-- Data for Name: artist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.artist (artist_id, genre_id, name, bio_desc) FROM stdin;
\.
COPY public.artist (artist_id, genre_id, name, bio_desc) FROM '$$PATH$$/3768.dat';

--
-- Data for Name: artist_review; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.artist_review (review_id, user_id, artist_id, rating, "desc", review_date) FROM stdin;
\.
COPY public.artist_review (review_id, user_id, artist_id, rating, "desc", review_date) FROM '$$PATH$$/3778.dat';

--
-- Data for Name: genre; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.genre (genre_id, name) FROM stdin;
\.
COPY public.genre (genre_id, name) FROM '$$PATH$$/3764.dat';

--
-- Data for Name: label; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.label (label_id, name, description, founding_date) FROM stdin;
\.
COPY public.label (label_id, name, description, founding_date) FROM '$$PATH$$/3766.dat';

--
-- Data for Name: playlist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.playlist (playlist_id, user_id, name, description) FROM stdin;
\.
COPY public.playlist (playlist_id, user_id, name, description) FROM '$$PATH$$/3776.dat';

--
-- Data for Name: song; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.song (song_id, genre_id, title, length) FROM stdin;
\.
COPY public.song (song_id, genre_id, title, length) FROM '$$PATH$$/3772.dat';

--
-- Data for Name: song_review; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.song_review (review_id, user_id, song_id, rating, "desc", review_date) FROM stdin;
\.
COPY public.song_review (review_id, user_id, song_id, rating, "desc", review_date) FROM '$$PATH$$/3782.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."user" (user_id, username, password, email, date_of_birth, join_date) FROM stdin;
\.
COPY public."user" (user_id, username, password, email, date_of_birth, join_date) FROM '$$PATH$$/3774.dat';

--
-- Data for Name: xref_album_artist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.xref_album_artist (album_artist_id, artist_id, album_id) FROM stdin;
\.
COPY public.xref_album_artist (album_artist_id, artist_id, album_id) FROM '$$PATH$$/3784.dat';

--
-- Data for Name: xref_album_song; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.xref_album_song (album_song_id, song_id, album_id) FROM stdin;
\.
COPY public.xref_album_song (album_song_id, song_id, album_id) FROM '$$PATH$$/3786.dat';

--
-- Data for Name: xref_artist_song; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.xref_artist_song (artist_song_id, song_id, artist_id) FROM stdin;
\.
COPY public.xref_artist_song (artist_song_id, song_id, artist_id) FROM '$$PATH$$/3788.dat';

--
-- Data for Name: xref_playlist_song; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.xref_playlist_song (playlist_song_id, song_id, playlist_id) FROM stdin;
\.
COPY public.xref_playlist_song (playlist_song_id, song_id, playlist_id) FROM '$$PATH$$/3790.dat';

--
-- Name: album_album_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.album_album_id_seq', 1, false);


--
-- Name: album_review_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.album_review_review_id_seq', 1, false);


--
-- Name: artist_artist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.artist_artist_id_seq', 1, false);


--
-- Name: artist_review_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.artist_review_review_id_seq', 1, false);


--
-- Name: genre_genre_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.genre_genre_id_seq', 45, true);


--
-- Name: label_label_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.label_label_id_seq', 4, true);


--
-- Name: playlist_playlist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.playlist_playlist_id_seq', 1, false);


--
-- Name: song_review_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.song_review_review_id_seq', 1, false);


--
-- Name: song_song_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.song_song_id_seq', 1, false);


--
-- Name: user_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_user_id_seq', 20, true);


--
-- Name: xref_album_artist_album_artist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.xref_album_artist_album_artist_id_seq', 20, true);


--
-- Name: xref_album_song_album_song_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.xref_album_song_album_song_id_seq', 60, true);


--
-- Name: xref_artist_song_artist_song_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.xref_artist_song_artist_song_id_seq', 60, true);


--
-- Name: xref_playlist_song_playlist_song_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.xref_playlist_song_playlist_song_id_seq', 25, true);


--
-- Name: album album_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.album
    ADD CONSTRAINT album_pkey PRIMARY KEY (album_id);


--
-- Name: album_review album_review_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.album_review
    ADD CONSTRAINT album_review_pkey PRIMARY KEY (review_id);


--
-- Name: artist artist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.artist
    ADD CONSTRAINT artist_pkey PRIMARY KEY (artist_id);


--
-- Name: artist_review artist_review_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.artist_review
    ADD CONSTRAINT artist_review_pkey PRIMARY KEY (review_id);


--
-- Name: genre genre_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genre
    ADD CONSTRAINT genre_pkey PRIMARY KEY (genre_id);


--
-- Name: label label_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.label
    ADD CONSTRAINT label_pkey PRIMARY KEY (label_id);


--
-- Name: playlist playlist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist
    ADD CONSTRAINT playlist_pkey PRIMARY KEY (playlist_id);


--
-- Name: song song_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song
    ADD CONSTRAINT song_pkey PRIMARY KEY (song_id);


--
-- Name: song_review song_review_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song_review
    ADD CONSTRAINT song_review_pkey PRIMARY KEY (review_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (user_id);


--
-- Name: xref_album_artist xref_album_artist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xref_album_artist
    ADD CONSTRAINT xref_album_artist_pkey PRIMARY KEY (album_artist_id);


--
-- Name: xref_album_song xref_album_song_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xref_album_song
    ADD CONSTRAINT xref_album_song_pkey PRIMARY KEY (album_song_id);


--
-- Name: xref_artist_song xref_artist_song_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xref_artist_song
    ADD CONSTRAINT xref_artist_song_pkey PRIMARY KEY (artist_song_id);


--
-- Name: xref_playlist_song xref_playlist_song_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xref_playlist_song
    ADD CONSTRAINT xref_playlist_song_pkey PRIMARY KEY (playlist_song_id);


--
-- Name: idx_album_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_album_id ON public.album USING btree (album_id);


--
-- Name: idx_artist_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_artist_id ON public.artist USING btree (artist_id);


--
-- Name: idx_genre; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_genre ON public.genre USING btree (genre_id, name);


--
-- Name: idx_label; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_label ON public.label USING btree (label_id, name, description, founding_date);


--
-- Name: idx_song_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_song_id ON public.song USING btree (song_id);


--
-- Name: idx_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_id ON public."user" USING btree (user_id);


--
-- Name: album_review album_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.album_review
    ADD CONSTRAINT album_id FOREIGN KEY (album_id) REFERENCES public.album(album_id);


--
-- Name: xref_album_artist album_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xref_album_artist
    ADD CONSTRAINT album_id FOREIGN KEY (album_id) REFERENCES public.album(album_id);


--
-- Name: xref_album_song album_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xref_album_song
    ADD CONSTRAINT album_id FOREIGN KEY (album_id) REFERENCES public.album(album_id);


--
-- Name: artist_review artist_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.artist_review
    ADD CONSTRAINT artist_id FOREIGN KEY (artist_id) REFERENCES public.artist(artist_id);


--
-- Name: xref_album_artist artist_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xref_album_artist
    ADD CONSTRAINT artist_id FOREIGN KEY (artist_id) REFERENCES public.artist(artist_id);


--
-- Name: xref_artist_song artist_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xref_artist_song
    ADD CONSTRAINT artist_id FOREIGN KEY (artist_id) REFERENCES public.artist(artist_id);


--
-- Name: artist genre_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.artist
    ADD CONSTRAINT genre_id FOREIGN KEY (genre_id) REFERENCES public.genre(genre_id);


--
-- Name: song genre_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song
    ADD CONSTRAINT genre_id FOREIGN KEY (genre_id) REFERENCES public.genre(genre_id);


--
-- Name: album label_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.album
    ADD CONSTRAINT label_id FOREIGN KEY (label_id) REFERENCES public.label(label_id);


--
-- Name: xref_playlist_song playlist_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xref_playlist_song
    ADD CONSTRAINT playlist_id FOREIGN KEY (playlist_id) REFERENCES public.playlist(playlist_id);


--
-- Name: song_review song_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song_review
    ADD CONSTRAINT song_id FOREIGN KEY (song_id) REFERENCES public.song(song_id);


--
-- Name: xref_album_song song_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xref_album_song
    ADD CONSTRAINT song_id FOREIGN KEY (song_id) REFERENCES public.song(song_id);


--
-- Name: xref_artist_song song_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xref_artist_song
    ADD CONSTRAINT song_id FOREIGN KEY (song_id) REFERENCES public.song(song_id);


--
-- Name: xref_playlist_song song_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.xref_playlist_song
    ADD CONSTRAINT song_id FOREIGN KEY (song_id) REFERENCES public.song(song_id);


--
-- Name: playlist user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist
    ADD CONSTRAINT user_id FOREIGN KEY (user_id) REFERENCES public."user"(user_id);


--
-- Name: artist_review user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.artist_review
    ADD CONSTRAINT user_id FOREIGN KEY (user_id) REFERENCES public."user"(user_id);


--
-- Name: album_review user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.album_review
    ADD CONSTRAINT user_id FOREIGN KEY (user_id) REFERENCES public."user"(user_id);


--
-- Name: song_review user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song_review
    ADD CONSTRAINT user_id FOREIGN KEY (user_id) REFERENCES public."user"(user_id);


--
-- PostgreSQL database dump complete
--

